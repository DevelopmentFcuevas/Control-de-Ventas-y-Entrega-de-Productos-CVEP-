package io.bootify.my_app.service;

import io.bootify.my_app.domain.Departamento;
import io.bootify.my_app.domain.Pais;
import io.bootify.my_app.model.DepartamentoDTO;
import io.bootify.my_app.repos.DepartamentoRepository;
import io.bootify.my_app.repos.PaisRepository;
import io.bootify.my_app.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class DepartamentoService {

    private final DepartamentoRepository departamentoRepository;
    private final PaisRepository paisRepository;

    public DepartamentoService(final DepartamentoRepository departamentoRepository,
            final PaisRepository paisRepository) {
        this.departamentoRepository = departamentoRepository;
        this.paisRepository = paisRepository;
    }

    public List<DepartamentoDTO> findAll() {
        final List<Departamento> departamentoes = departamentoRepository.findAll(Sort.by("id"));
        return departamentoes.stream()
                .map(departamento -> mapToDTO(departamento, new DepartamentoDTO()))
                .toList();
    }

    public DepartamentoDTO get(final Long id) {
        return departamentoRepository.findById(id)
                .map(departamento -> mapToDTO(departamento, new DepartamentoDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final DepartamentoDTO departamentoDTO) {
        final Departamento departamento = new Departamento();
        mapToEntity(departamentoDTO, departamento);
        return departamentoRepository.save(departamento).getId();
    }

    public void update(final Long id, final DepartamentoDTO departamentoDTO) {
        final Departamento departamento = departamentoRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(departamentoDTO, departamento);
        departamentoRepository.save(departamento);
    }

    public void delete(final Long id) {
        departamentoRepository.deleteById(id);
    }

    private DepartamentoDTO mapToDTO(final Departamento departamento,
            final DepartamentoDTO departamentoDTO) {
        departamentoDTO.setId(departamento.getId());
        departamentoDTO.setName(departamento.getName());
        departamentoDTO.setPaisId(departamento.getPaisId());
        departamentoDTO.setPaises(departamento.getPaises() == null ? null : departamento.getPaises().getId());
        return departamentoDTO;
    }

    private Departamento mapToEntity(final DepartamentoDTO departamentoDTO,
            final Departamento departamento) {
        departamento.setName(departamentoDTO.getName());
        departamento.setPaisId(departamentoDTO.getPaisId());
        final Pais paises = departamentoDTO.getPaises() == null ? null : paisRepository.findById(departamentoDTO.getPaises())
                .orElseThrow(() -> new NotFoundException("paises not found"));
        departamento.setPaises(paises);
        return departamento;
    }

}
