package io.bootify.my_app.service;

import io.bootify.my_app.domain.Departamento;
import io.bootify.my_app.domain.Pais;
import io.bootify.my_app.model.PaisDTO;
import io.bootify.my_app.repos.DepartamentoRepository;
import io.bootify.my_app.repos.PaisRepository;
import io.bootify.my_app.util.NotFoundException;
import io.bootify.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class PaisService {

    private final PaisRepository paisRepository;
    private final DepartamentoRepository departamentoRepository;

    public PaisService(final PaisRepository paisRepository,
            final DepartamentoRepository departamentoRepository) {
        this.paisRepository = paisRepository;
        this.departamentoRepository = departamentoRepository;
    }

    public List<PaisDTO> findAll() {
        final List<Pais> paises = paisRepository.findAll(Sort.by("id"));
        return paises.stream()
                .map(pais -> mapToDTO(pais, new PaisDTO()))
                .toList();
    }

    public PaisDTO get(final Long id) {
        return paisRepository.findById(id)
                .map(pais -> mapToDTO(pais, new PaisDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final PaisDTO paisDTO) {
        final Pais pais = new Pais();
        mapToEntity(paisDTO, pais);
        return paisRepository.save(pais).getId();
    }

    public void update(final Long id, final PaisDTO paisDTO) {
        final Pais pais = paisRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(paisDTO, pais);
        paisRepository.save(pais);
    }

    public void delete(final Long id) {
        paisRepository.deleteById(id);
    }

    private PaisDTO mapToDTO(final Pais pais, final PaisDTO paisDTO) {
        paisDTO.setId(pais.getId());
        paisDTO.setName(pais.getName());
        return paisDTO;
    }

    private Pais mapToEntity(final PaisDTO paisDTO, final Pais pais) {
        pais.setName(paisDTO.getName());
        return pais;
    }

    public boolean nameExists(final String name) {
        return paisRepository.existsByNameIgnoreCase(name);
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Pais pais = paisRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Departamento paisesDepartamento = departamentoRepository.findFirstByPaises(pais);
        if (paisesDepartamento != null) {
            referencedWarning.setKey("pais.departamento.paises.referenced");
            referencedWarning.addParam(paisesDepartamento.getId());
            return referencedWarning;
        }
        return null;
    }

}
