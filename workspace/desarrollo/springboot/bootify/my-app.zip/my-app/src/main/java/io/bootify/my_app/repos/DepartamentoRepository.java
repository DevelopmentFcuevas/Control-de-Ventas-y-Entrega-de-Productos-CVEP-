package io.bootify.my_app.repos;

import io.bootify.my_app.domain.Departamento;
import io.bootify.my_app.domain.Pais;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DepartamentoRepository extends JpaRepository<Departamento, Long> {

    Departamento findFirstByPaises(Pais pais);

}
