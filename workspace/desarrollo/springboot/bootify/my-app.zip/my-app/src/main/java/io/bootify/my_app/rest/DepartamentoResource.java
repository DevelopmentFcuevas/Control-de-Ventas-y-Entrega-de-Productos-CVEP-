package io.bootify.my_app.rest;

import io.bootify.my_app.model.DepartamentoDTO;
import io.bootify.my_app.service.DepartamentoService;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/departamentos", produces = MediaType.APPLICATION_JSON_VALUE)
public class DepartamentoResource {

    private final DepartamentoService departamentoService;

    public DepartamentoResource(final DepartamentoService departamentoService) {
        this.departamentoService = departamentoService;
    }

    @GetMapping
    public ResponseEntity<List<DepartamentoDTO>> getAllDepartamentos() {
        return ResponseEntity.ok(departamentoService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<DepartamentoDTO> getDepartamento(
            @PathVariable(name = "id") final Long id) {
        return ResponseEntity.ok(departamentoService.get(id));
    }

    @PostMapping
    @ApiResponse(responseCode = "201")
    public ResponseEntity<Long> createDepartamento(
            @RequestBody @Valid final DepartamentoDTO departamentoDTO) {
        final Long createdId = departamentoService.create(departamentoDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Long> updateDepartamento(@PathVariable(name = "id") final Long id,
            @RequestBody @Valid final DepartamentoDTO departamentoDTO) {
        departamentoService.update(id, departamentoDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    @ApiResponse(responseCode = "204")
    public ResponseEntity<Void> deleteDepartamento(@PathVariable(name = "id") final Long id) {
        departamentoService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
