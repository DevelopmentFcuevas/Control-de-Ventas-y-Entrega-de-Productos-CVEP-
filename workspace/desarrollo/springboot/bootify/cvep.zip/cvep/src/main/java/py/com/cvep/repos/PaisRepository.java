package py.com.cvep.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import py.com.cvep.domain.Pais;


public interface PaisRepository extends JpaRepository<Pais, Long> {
}
