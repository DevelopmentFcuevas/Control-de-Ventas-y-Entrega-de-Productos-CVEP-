package py.com.cvep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CvepApplication {

    public static void main(final String[] args) {
        SpringApplication.run(CvepApplication.class, args);
    }

}
