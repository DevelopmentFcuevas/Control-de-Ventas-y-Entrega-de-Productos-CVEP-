package py.com.cvep.service;

import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import py.com.cvep.domain.Pais;
import py.com.cvep.model.PaisDTO;
import py.com.cvep.repos.PaisRepository;
import py.com.cvep.util.NotFoundException;


@Service
public class PaisService {

    private final PaisRepository paisRepository;

    public PaisService(final PaisRepository paisRepository) {
        this.paisRepository = paisRepository;
    }

    public List<PaisDTO> findAll() {
        final List<Pais> paiss = paisRepository.findAll(Sort.by("id"));
        return paiss.stream()
                .map(pais -> mapToDTO(pais, new PaisDTO()))
                .toList();
    }

    public PaisDTO get(final Long id) {
        return paisRepository.findById(id)
                .map(pais -> mapToDTO(pais, new PaisDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final PaisDTO paisDTO) {
        final Pais pais = new Pais();
        mapToEntity(paisDTO, pais);
        return paisRepository.save(pais).getId();
    }

    public void update(final Long id, final PaisDTO paisDTO) {
        final Pais pais = paisRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(paisDTO, pais);
        paisRepository.save(pais);
    }

    public void delete(final Long id) {
        paisRepository.deleteById(id);
    }

    private PaisDTO mapToDTO(final Pais pais, final PaisDTO paisDTO) {
        paisDTO.setId(pais.getId());
        paisDTO.setNombre(pais.getNombre());
        return paisDTO;
    }

    private Pais mapToEntity(final PaisDTO paisDTO, final Pais pais) {
        pais.setNombre(paisDTO.getNombre());
        return pais;
    }

}
