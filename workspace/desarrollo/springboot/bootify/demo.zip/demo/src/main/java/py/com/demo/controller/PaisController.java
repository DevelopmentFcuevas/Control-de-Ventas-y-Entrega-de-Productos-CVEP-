package py.com.demo.controller;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import py.com.demo.model.PaisDTO;
import py.com.demo.service.PaisService;
import py.com.demo.util.WebUtils;


@Controller
@RequestMapping("/paiss")
public class PaisController {

    private final PaisService paisService;

    public PaisController(final PaisService paisService) {
        this.paisService = paisService;
    }

    @GetMapping
    public String list(final Model model) {
        model.addAttribute("paiss", paisService.findAll());
        return "pais/list";
    }

    @GetMapping("/add")
    public String add(@ModelAttribute("pais") final PaisDTO paisDTO) {
        return "pais/add";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute("pais") @Valid final PaisDTO paisDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "pais/add";
        }
        paisService.create(paisDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("pais.create.success"));
        return "redirect:/paiss";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable final Long id, final Model model) {
        model.addAttribute("pais", paisService.get(id));
        return "pais/edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable final Long id,
            @ModelAttribute("pais") @Valid final PaisDTO paisDTO, final BindingResult bindingResult,
            final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "pais/edit";
        }
        paisService.update(id, paisDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("pais.update.success"));
        return "redirect:/paiss";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable final Long id, final RedirectAttributes redirectAttributes) {
        paisService.delete(id);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("pais.delete.success"));
        return "redirect:/paiss";
    }

}
