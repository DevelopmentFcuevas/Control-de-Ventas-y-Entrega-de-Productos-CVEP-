package py.com.demo.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import py.com.demo.domain.Pais;


public interface PaisRepository extends JpaRepository<Pais, Long> {
}
