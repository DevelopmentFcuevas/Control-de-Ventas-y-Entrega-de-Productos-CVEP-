package py.com.housesolutions.ms_cvep_paises.service;

import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import py.com.housesolutions.ms_cvep_paises.domain.Countries;
import py.com.housesolutions.ms_cvep_paises.model.CountriesDTO;
import py.com.housesolutions.ms_cvep_paises.repos.CountriesRepository;
import py.com.housesolutions.ms_cvep_paises.util.NotFoundException;


@Service
public class CountriesService {

    private final CountriesRepository countriesRepository;

    public CountriesService(final CountriesRepository countriesRepository) {
        this.countriesRepository = countriesRepository;
    }

    public List<CountriesDTO> findAll() {
        final List<Countries> countrieses = countriesRepository.findAll(Sort.by("id"));
        return countrieses.stream()
                .map(countries -> mapToDTO(countries, new CountriesDTO()))
                .toList();
    }

    public CountriesDTO get(final Long id) {
        return countriesRepository.findById(id)
                .map(countries -> mapToDTO(countries, new CountriesDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final CountriesDTO countriesDTO) {
        final Countries countries = new Countries();
        mapToEntity(countriesDTO, countries);
        return countriesRepository.save(countries).getId();
    }

    public void update(final Long id, final CountriesDTO countriesDTO) {
        final Countries countries = countriesRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(countriesDTO, countries);
        countriesRepository.save(countries);
    }

    public void delete(final Long id) {
        countriesRepository.deleteById(id);
    }

    private CountriesDTO mapToDTO(final Countries countries, final CountriesDTO countriesDTO) {
        countriesDTO.setId(countries.getId());
        countriesDTO.setName(countries.getName());
        countriesDTO.setEstado(countries.getEstado());
        return countriesDTO;
    }

    private Countries mapToEntity(final CountriesDTO countriesDTO, final Countries countries) {
        countries.setName(countriesDTO.getName());
        countries.setEstado(countriesDTO.getEstado());
        return countries;
    }

}
