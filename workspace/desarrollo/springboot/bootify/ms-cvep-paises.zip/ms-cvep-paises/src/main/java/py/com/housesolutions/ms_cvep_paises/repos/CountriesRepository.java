package py.com.housesolutions.ms_cvep_paises.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import py.com.housesolutions.ms_cvep_paises.domain.Countries;


public interface CountriesRepository extends JpaRepository<Countries, Long> {
}
