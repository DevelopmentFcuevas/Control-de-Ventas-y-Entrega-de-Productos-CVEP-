package py.com.housesolutions.ms_cvep_paises.rest;

import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import py.com.housesolutions.ms_cvep_paises.model.CountriesDTO;
import py.com.housesolutions.ms_cvep_paises.service.CountriesService;


@RestController
@RequestMapping(value = "/api/countriess", produces = MediaType.APPLICATION_JSON_VALUE)
public class CountriesResource {

    private final CountriesService countriesService;

    public CountriesResource(final CountriesService countriesService) {
        this.countriesService = countriesService;
    }

    @GetMapping
    public ResponseEntity<List<CountriesDTO>> getAllCountriess() {
        return ResponseEntity.ok(countriesService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CountriesDTO> getCountries(@PathVariable(name = "id") final Long id) {
        return ResponseEntity.ok(countriesService.get(id));
    }

    @PostMapping
    public ResponseEntity<Long> createCountries(
            @RequestBody @Valid final CountriesDTO countriesDTO) {
        final Long createdId = countriesService.create(countriesDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Long> updateCountries(@PathVariable(name = "id") final Long id,
            @RequestBody @Valid final CountriesDTO countriesDTO) {
        countriesService.update(id, countriesDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCountries(@PathVariable(name = "id") final Long id) {
        countriesService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
