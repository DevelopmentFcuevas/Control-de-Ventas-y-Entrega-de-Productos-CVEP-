package py.com.housesolutions.ms_cvep_paises.model;


public enum Estado {

    ACTIVO,
    INACTIVO

}
