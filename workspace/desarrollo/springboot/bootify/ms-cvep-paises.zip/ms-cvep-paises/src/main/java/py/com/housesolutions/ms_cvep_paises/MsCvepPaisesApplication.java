package py.com.housesolutions.ms_cvep_paises;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class MsCvepPaisesApplication {

    public static void main(final String[] args) {
        SpringApplication.run(MsCvepPaisesApplication.class, args);
    }

}
