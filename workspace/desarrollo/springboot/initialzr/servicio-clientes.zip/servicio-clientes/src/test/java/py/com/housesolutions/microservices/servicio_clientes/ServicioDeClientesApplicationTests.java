package py.com.housesolutions.microservices.servicio_clientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioDeClientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
