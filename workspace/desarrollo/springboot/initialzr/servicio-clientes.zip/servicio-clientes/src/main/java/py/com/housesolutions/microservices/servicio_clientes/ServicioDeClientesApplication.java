package py.com.housesolutions.microservices.servicio_clientes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicioDeClientesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioDeClientesApplication.class, args);
	}

}
