package py.com.housesolutions.microservices.servicio_ubicaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioDeUbicacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
