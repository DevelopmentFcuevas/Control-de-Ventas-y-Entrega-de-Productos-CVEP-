package py.com.housesolutions.microservices.servicio_ubicaciones.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaisRequestDTO {
    private Long id;
    private String name;
}
