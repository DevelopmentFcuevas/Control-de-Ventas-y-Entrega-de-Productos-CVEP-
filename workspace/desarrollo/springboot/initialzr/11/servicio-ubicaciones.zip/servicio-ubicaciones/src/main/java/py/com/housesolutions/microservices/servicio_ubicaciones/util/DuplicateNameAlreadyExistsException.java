package py.com.housesolutions.microservices.servicio_ubicaciones.util;

public class DuplicateNameAlreadyExistsException extends RuntimeException {
    public DuplicateNameAlreadyExistsException(String message) {
        super(message);
    }
}
