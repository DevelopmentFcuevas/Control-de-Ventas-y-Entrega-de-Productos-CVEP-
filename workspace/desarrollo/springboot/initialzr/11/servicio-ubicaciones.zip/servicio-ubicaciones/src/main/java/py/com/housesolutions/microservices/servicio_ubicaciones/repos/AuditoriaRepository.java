package py.com.housesolutions.microservices.servicio_ubicaciones.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import py.com.housesolutions.microservices.servicio_ubicaciones.domain.Auditoria;

public interface AuditoriaRepository extends JpaRepository<Auditoria, Long> {
}
