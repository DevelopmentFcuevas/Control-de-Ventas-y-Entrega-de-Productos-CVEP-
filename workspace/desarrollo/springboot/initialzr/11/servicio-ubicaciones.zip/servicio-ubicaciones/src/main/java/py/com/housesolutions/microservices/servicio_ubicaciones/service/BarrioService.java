package py.com.housesolutions.microservices.servicio_ubicaciones.service;

import py.com.housesolutions.microservices.servicio_ubicaciones.domain.Barrio;
import py.com.housesolutions.microservices.servicio_ubicaciones.model.BarrioCreateDTO;
import py.com.housesolutions.microservices.servicio_ubicaciones.model.BarrioDTO;
import py.com.housesolutions.microservices.servicio_ubicaciones.model.BarrioResponseDTO;
import py.com.housesolutions.microservices.servicio_ubicaciones.model.BarrioUpdateDTO;

import java.util.List;

public interface BarrioService {
    BarrioDTO mapToDTO(Barrio entity);
    BarrioResponseDTO mapToResponseDTO(Barrio entity);
    Barrio mapToEntity(BarrioDTO dto);
    List<BarrioResponseDTO> findAll() throws Exception;
    BarrioResponseDTO get(Long id) throws Exception;
    BarrioResponseDTO create(BarrioCreateDTO request) throws Exception;
    BarrioResponseDTO update(Long id, BarrioUpdateDTO request ) throws Exception;
    void delete(Long id) throws Exception;
}
