package py.com.housesolutions.microservices.servicio_ubicaciones.util;

public class InternalServerErrorException extends RuntimeException {
    public InternalServerErrorException(String message) {
        super(message);

    }
}
