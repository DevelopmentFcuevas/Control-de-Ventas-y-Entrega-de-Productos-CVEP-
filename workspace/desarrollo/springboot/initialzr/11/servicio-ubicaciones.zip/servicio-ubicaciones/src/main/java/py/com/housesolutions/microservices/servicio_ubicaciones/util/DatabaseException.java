package py.com.housesolutions.microservices.servicio_ubicaciones.util;

public class DatabaseException extends RuntimeException {
    public DatabaseException(String message) {
        super(message);
    }
}
