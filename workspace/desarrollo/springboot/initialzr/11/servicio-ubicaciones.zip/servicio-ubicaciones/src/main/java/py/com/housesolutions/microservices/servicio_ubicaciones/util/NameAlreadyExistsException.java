package py.com.housesolutions.microservices.servicio_ubicaciones.util;

public class NameAlreadyExistsException extends RuntimeException {
    public NameAlreadyExistsException(String message) {
        super(message);
    }
}
