package py.com.housesolutions.microservices.servicio_ubicaciones;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import py.com.housesolutions.microservices.servicio_ubicaciones.domain.Pais;
import py.com.housesolutions.microservices.servicio_ubicaciones.model.PaisDTO;
import py.com.housesolutions.microservices.servicio_ubicaciones.repos.PaisRepository;
import py.com.housesolutions.microservices.servicio_ubicaciones.service.PaisService;
import py.com.housesolutions.microservices.servicio_ubicaciones.service.implementation.PaisServiceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class PaisServiceImplTest {
    @InjectMocks
    private PaisServiceImpl service;
    @Mock
    private PaisRepository repository;
    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this); // Inicializa los mocks
    }

    /*@Test
    public void testCreatePais() throws Exception {
        PaisDTO dto = new PaisDTO();
        dto.setName("Argentina");
        Pais savedPais = new Pais();
        savedPais.setId(3L);

        when(repository.save(any(Pais.class))).thenReturn(savedPais);

        PaisDTO result = service.create(dto);

        assertNotNull(result); // Verifica que el resultado no sea nulo
        assertEquals(result.getId(), 1L); // Compara el ID esperado
        verify(repository, times(1)).save(any(Pais.class)); // Verifica que se haya llamado a 'save'
    }*/

}
