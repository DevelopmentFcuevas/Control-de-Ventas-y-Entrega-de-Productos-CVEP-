package py.com.housesolutions.microservices.servicio_ubicaciones.service;

import py.com.housesolutions.microservices.servicio_ubicaciones.domain.Ciudad;
import py.com.housesolutions.microservices.servicio_ubicaciones.model.*;

import java.util.List;

public interface CiudadService {
    CiudadDTO mapToDTO(Ciudad entity);
    CiudadResponseDTO mapToResponseDTO(Ciudad entity);
    Ciudad mapToEntity(CiudadDTO dto);
    List<CiudadResponseDTO> findAll() throws Exception;
    CiudadResponseDTO get(Long id) throws Exception;
    CiudadDTO getAll(Long id) throws Exception;
    CiudadResponseDTO create(CiudadCreateDTO dto) throws Exception;
    CiudadResponseDTO update(Long id, CiudadUpdateDTO dto) throws Exception;
    void delete(final Long id) throws Exception;
}
