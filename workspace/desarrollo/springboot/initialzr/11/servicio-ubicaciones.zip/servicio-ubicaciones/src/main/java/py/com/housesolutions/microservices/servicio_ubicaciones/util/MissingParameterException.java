package py.com.housesolutions.microservices.servicio_ubicaciones.util;

public class MissingParameterException extends RuntimeException {
    public MissingParameterException(String message) {
        super(message);
    }
}
