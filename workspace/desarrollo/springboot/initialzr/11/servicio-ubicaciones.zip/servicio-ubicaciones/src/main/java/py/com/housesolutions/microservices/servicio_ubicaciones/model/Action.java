package py.com.housesolutions.microservices.servicio_ubicaciones.model;

public enum Action {
    CREATE,
    UPDATE,
    DELETE,
    REACTIVATED,
}
