package py.com.housesolutions.microservices.servicio_ubicaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicioDeUbicacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioDeUbicacionesApplication.class, args);
	}

}
