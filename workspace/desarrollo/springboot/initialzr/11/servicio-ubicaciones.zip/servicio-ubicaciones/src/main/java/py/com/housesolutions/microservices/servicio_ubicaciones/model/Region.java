package py.com.housesolutions.microservices.servicio_ubicaciones.model;

public enum Region {
    ORIENTAL,
    OCCIDENTAL,
    SIN_ESPECIFICAR
}
