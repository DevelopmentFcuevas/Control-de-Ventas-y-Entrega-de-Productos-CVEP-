package py.com.housesolutions.microservices.servicio_ubicaciones.model;

public enum Continente {
    ASIA,
    AFRICA,
    AMERICA_DEL_NORTE,
    AMERICA_DEL_SUR,
    ANTARTIDA,
    EUROPA,
    OCEANIA,
    SIN_ESPECIFICAR
}
