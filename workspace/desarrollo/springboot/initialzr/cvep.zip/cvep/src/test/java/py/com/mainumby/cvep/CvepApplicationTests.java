package py.com.mainumby.cvep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CvepApplicationTests {

	@Test
	void contextLoads() {
	}

}
