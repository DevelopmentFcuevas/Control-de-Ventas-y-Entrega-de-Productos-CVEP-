package py.com.mainumby.cvep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CvepApplication {

	public static void main(String[] args) {
		SpringApplication.run(CvepApplication.class, args);
	}

}
