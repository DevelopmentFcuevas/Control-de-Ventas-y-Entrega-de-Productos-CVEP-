package py.com.housesolutions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCvepGeographyApplicationTests {

	@Test
	void contextLoads() {
	}

}
