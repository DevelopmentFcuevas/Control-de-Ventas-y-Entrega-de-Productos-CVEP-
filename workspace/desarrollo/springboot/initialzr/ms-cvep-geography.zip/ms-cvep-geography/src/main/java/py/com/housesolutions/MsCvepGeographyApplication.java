package py.com.housesolutions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsCvepGeographyApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsCvepGeographyApplication.class, args);
	}

}
